package com.powerrise.data;

import com.powerrise.powers.PowerType;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerData {
    private final UUID uuid;
    private PowerType currentPower;
    private int totalKills;
    private Map<String, Long> cooldowns;
    private Map<String, Boolean> unlockedAbilities;
    
    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.totalKills = 0;
        this.cooldowns = new HashMap<>();
        this.unlockedAbilities = new HashMap<>();
    }
    
    public PlayerData(UUID uuid, PowerType power, int kills) {
        this(uuid);
        this.currentPower = power;
        this.totalKills = kills;
        updateUnlockedAbilities();
    }
    
    public UUID getUuid() {
        return uuid;
    }
    
    public PowerType getCurrentPower() {
        return currentPower;
    }
    
    public void setCurrentPower(PowerType power) {
        this.currentPower = power;
        updateUnlockedAbilities();
    }
    
    public int getTotalKills() {
        return totalKills;
    }
    
    public void addKill() {
        this.totalKills++;
        updateUnlockedAbilities();
    }
    
    public void resetKills() {
        this.totalKills = 0;
        updateUnlockedAbilities();
    }
    
    public boolean isOnCooldown(String ability) {
        Long cooldownEnd = cooldowns.get(ability);
        if (cooldownEnd == null) return false;
        return System.currentTimeMillis() < cooldownEnd;
    }
    
    public void setCooldown(String ability, long durationMs) {
        cooldowns.put(ability, System.currentTimeMillis() + durationMs);
    }
    
    public long getRemainingCooldown(String ability) {
        Long cooldownEnd = cooldowns.get(ability);
        if (cooldownEnd == null) return 0;
        return Math.max(0, cooldownEnd - System.currentTimeMillis());
    }
    
    public boolean hasAbilityUnlocked(String ability) {
        return unlockedAbilities.getOrDefault(ability, false);
    }
    
    private void updateUnlockedAbilities() {
        if (currentPower == null) return;
        
        String powerName = currentPower.name().toLowerCase();
        
        // Habilidades se desbloquean con 1, 3, 5 kills
        unlockedAbilities.put(powerName + "_ability_1", totalKills >= 1);
        unlockedAbilities.put(powerName + "_ability_2", totalKills >= 3);
        unlockedAbilities.put(powerName + "_ability_3", totalKills >= 5);
        
        // También mantener las claves antiguas para compatibilidad
        unlockedAbilities.put(powerName + "_1", totalKills >= 1);
        unlockedAbilities.put(powerName + "_2", totalKills >= 3);
        unlockedAbilities.put(powerName + "_3", totalKills >= 5);
    }
    
    public Map<String, Boolean> getUnlockedAbilities() {
        return new HashMap<>(unlockedAbilities);
    }
    
    public Map<String, Long> getCooldowns() {
        return new HashMap<>(cooldowns);
    }
}
