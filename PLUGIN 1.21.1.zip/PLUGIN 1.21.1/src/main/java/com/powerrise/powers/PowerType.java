package com.powerrise.powers;

import org.bukkit.ChatColor;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public enum PowerType {
    FIRE("Fuego", "🔥", ChatColor.RED),
    EARTH("Tierra", "🌍", ChatColor.GREEN),
    SHADOW("Sombras", "🌑", ChatColor.DARK_PURPLE),
    SKY("Cielo", "☁️", ChatColor.AQUA);
    
    private final String displayName;
    private final String emoji;
    private final ChatColor color;
    
    PowerType(String displayName, String emoji, ChatColor color) {
        this.displayName = displayName;
        this.emoji = emoji;
        this.color = color;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public String getEmoji() {
        return emoji;
    }
    
    public ChatColor getColor() {
        return color;
    }
    
    public String getFormattedName() {
        return color + emoji + " " + displayName + ChatColor.RESET;
    }

    public String getPassive() {
        switch (this) {
            case FIRE:
                return color + "🔥 Inmunidad al fuego.";
            case EARTH:
                return color + "🌍 Prisa minera.";
            case SHADOW:
                return color + "🌑 Velocidad.";
            case SKY:
                return color + "☁️ Anulacion de daño de caida.";
            default:
                return "";
    }
    }
    
public static PowerType getRandomPower(PowerType currentPower) {
    List<PowerType> powers = new ArrayList<>(List.of(values()));
    powers.remove(currentPower);

    if (powers.isEmpty()) {
        return currentPower; // fallback, though unlikely
    }

    return powers.get((int) (Math.random() * powers.size()));
}

public static PowerType getRandomPowerN() {
    PowerType[] powers = values();
    return powers[(int) (Math.random() * powers.length)];
}
}
