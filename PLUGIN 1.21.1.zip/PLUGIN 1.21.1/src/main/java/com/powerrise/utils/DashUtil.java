package com.powerrise.utils;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class DashUtil {
    
    /**
     * Realiza un dash seguro verificando colisiones
     */
    public static boolean performSafeDash(Player player, double distance) {
        Location startLoc = player.getLocation();
        Vector direction = startLoc.getDirection();
        
        // Calcular posición objetivo
        Location targetLoc = startLoc.clone().add(direction.multiply(distance));
        
        // Verificar si la posición es segura
        if (!isSafeLocation(targetLoc)) {
            // Buscar posición segura más cercana
            targetLoc = findSafeLocation(startLoc, direction, distance);
            if (targetLoc == null) {
                player.sendMessage("§c⚡ No se puede hacer dash - obstáculo bloqueando!");
                return false;
            }
        }
        
        // Teletransportar al jugador
        player.teleport(targetLoc);
        return true;
    }
    
    /**
     * Verifica si una ubicación es segura para el jugador
     */
    private static boolean isSafeLocation(Location loc) {
        Block feet = loc.getBlock();
        Block head = loc.clone().add(0, 1, 0).getBlock();
        Block ground = loc.clone().add(0, -1, 0).getBlock();
        
        // Verificar que los pies y cabeza estén libres
        if (!feet.getType().isAir() || !head.getType().isAir()) {
            return false;
        }
        
        // Verificar que haya suelo sólido
        return ground.getType().isSolid();
    }
    
    /**
     * Busca una ubicación segura en la dirección del dash
     */
    private static Location findSafeLocation(Location start, Vector direction, double maxDistance) {
        for (double d = 1.0; d <= maxDistance; d += 0.5) {
            Location testLoc = start.clone().add(direction.clone().multiply(d));
            if (isSafeLocation(testLoc)) {
                return testLoc;
            }
        }
        return null;
    }
}
