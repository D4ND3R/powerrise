package com.powerrise.utils;

import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class SafeUtils {
    
    public static void addPotionEffectSafe(Player player, PotionEffectType type, int duration, int amplifier) {
        try {
            player.addPotionEffect(new PotionEffect(type, duration, amplifier, false, false));
        } catch (Exception e) {
            // Fallback silencioso si hay problemas con efectos
        }
    }
    
    public static void sendActionBarSafe(Player player, String message) {
        try {
            player.sendActionBar(message);
        } catch (Exception e) {
            // Fallback a mensaje normal si actionbar no funciona
            player.sendMessage(message);
        }
    }
    
    public static void sendTitleSafe(Player player, String title, String subtitle, int fadeIn, int stay, int fadeOut) {
        try {
            player.sendTitle(title, subtitle, fadeIn, stay, fadeOut);
        } catch (Exception e) {
            // Fallback a mensaje normal si title no funciona
            player.sendMessage(title + (subtitle != null ? " - " + subtitle : ""));
        }
    }
}
