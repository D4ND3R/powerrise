package com.powerrise.utils;

import org.bukkit.Bukkit;

public class VersionUtil {
    private static final String VERSION = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
    
    public static boolean isVersion(String version) {
        return VERSION.equals(version);
    }
    
    public static boolean isVersionOrHigher(String version) {
        return VERSION.compareTo(version) >= 0;
    }
    
    public static String getVersion() {
        return VERSION;
    }
    
    public static boolean isLegacy() {
        return VERSION.startsWith("v1_12") || VERSION.startsWith("v1_11") || VERSION.startsWith("v1_10");
    }
}
