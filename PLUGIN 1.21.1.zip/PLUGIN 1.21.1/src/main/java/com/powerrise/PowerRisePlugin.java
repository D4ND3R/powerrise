package com.powerrise;

import com.powerrise.commands.PowerCommand;
import com.powerrise.listeners.*;
import com.powerrise.managers.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.Bukkit;

public class PowerRisePlugin extends JavaPlugin {
    
    private static PowerRisePlugin instance;
    private PlayerDataManager playerDataManager;
    private PowerManager powerManager;
    private MessageManager messageManager;
    private CraftingManager craftingManager;
    private TitleManager titleManager;
    private HUDManager hudManager;
    private KeyItemManager keyItemManager;
    private ModMessageListener modListener;
    private AbilityKeyListener abilityListener;
    
    @Override
    public void onEnable() {
        instance = this;
        
        try {
            // Crear carpetas y archivos de configuración
            saveDefaultConfig();
            
            // Inicializar managers
            this.messageManager = new MessageManager(this);
            this.playerDataManager = new PlayerDataManager(this);
            this.powerManager = new PowerManager(this);
            this.craftingManager = new CraftingManager(this);
            this.titleManager = new TitleManager(this);
            this.hudManager = new HUDManager(this);
            this.keyItemManager = new KeyItemManager(this);
            
            // Create listeners
            this.modListener = new ModMessageListener(this);
            this.abilityListener = new AbilityKeyListener(this);
            
            // Register plugin channels for Fabric client mod (UPDATED FOR 1.21.1)
            Bukkit.getMessenger().registerIncomingPluginChannel(this, "powerrise:ability", abilityListener);
            Bukkit.getMessenger().registerIncomingPluginChannel(this, "powerrise:mod", modListener);
            
            // Register event listener for mod message listener (for player quit cleanup)
            getServer().getPluginManager().registerEvents(modListener, this);
            
            // Registrar eventos
            registerEvents();
            
            // Registrar comandos
            registerCommands();
            
            // Registrar crafteos personalizados
            craftingManager.registerCustomRecipes();
            
            getLogger().info("PowerRise plugin habilitado correctamente!");
            getLogger().info("🔥 DETECCIÓN REAL DE TECLAS X, C, V ACTIVADA!");
            getLogger().info("📦 Los jugadores necesitan instalar el mod del cliente:");
            getLogger().info("   1. Instalar Fabric Loader 1.21.1");
            getLogger().info("   2. Instalar powerrise-client-1.0.0.jar en mods/");
            getLogger().info("   3. ¡Las teclas X, C, V funcionarán literalmente!");
            
        } catch (Exception e) {
            getLogger().severe("Error habilitando PowerRise: " + e.getMessage());
            e.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
        }
    }
    
    @Override
    public void onDisable() {
        try {
            if (playerDataManager != null) {
                playerDataManager.saveAllData();
            }
            
            // Desregistrar canales del mod
            getServer().getMessenger().unregisterIncomingPluginChannel(this, "powerrise:ability");
            getServer().getMessenger().unregisterIncomingPluginChannel(this, "powerrise:mod");
            
            getLogger().info("PowerRise plugin deshabilitado.");
        } catch (Exception e) {
            getLogger().severe("Error deshabilitando PowerRise: " + e.getMessage());
        }
    }
    
    private void registerEvents() {
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerDeathListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerQuitListener(this), this);
        getServer().getPluginManager().registerEvents(new EntityDamageListener(this), this);
        getServer().getPluginManager().registerEvents(new KeyPressListener(this), this);
        getServer().getPluginManager().registerEvents(new CraftingListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerInteractListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerRespawnListener(this), this);
        getServer().getPluginManager().registerEvents(new PowerEvents(this), this);
        getServer().getPluginManager().registerEvents(new FireAuraListener(this), this);
    }
    
    private void registerCommands() {
        PowerCommand powerCommand = new PowerCommand(this);
        getCommand("power").setExecutor(powerCommand);
        getCommand("power").setTabCompleter(powerCommand);
    }
    
    // Getters estáticos
    public static PowerRisePlugin getInstance() {
        return instance;
    }
    
    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }
    
    public PowerManager getPowerManager() {
        return powerManager;
    }
    
    public MessageManager getMessageManager() {
        return messageManager;
    }
    
    public CraftingManager getCraftingManager() {
        return craftingManager;
    }
    
    public TitleManager getTitleManager() {
        return titleManager;
    }
    
    public HUDManager getHUDManager() {
        return hudManager;
    }
    
    public KeyItemManager getKeyItemManager() {
        return keyItemManager;
    }
}