package com.powerrise.commands;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.powers.PowerType;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PowerCommand implements CommandExecutor, TabCompleter {
    private final PowerRisePlugin plugin;
    
    public PowerCommand(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player) {
                showPlayerPower((Player) sender);
            } else {
                sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden ver su poder.");
                sender.sendMessage(ChatColor.YELLOW + "Usa: /power help para ver comandos disponibles");
            }
            return true;
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "help":
            case "ayuda":
                showHelp(sender);
                break;
                
            case "teclas":
            case "keys":
            case "controles":
                showKeyInstructions(sender);
                break;
                
            case "ver":
            case "info":
            case "see":
                handleInfoCommand(sender, args);
                break;
                
            case "admin":
                handleAdminCommand(sender, args);
                break;
                
            case "reload":
                handleReloadCommand(sender);
                break;
                
            default:
                sender.sendMessage(ChatColor.RED + "Subcomando desconocido: " + subCommand);
                sender.sendMessage(ChatColor.YELLOW + "Usa /power help para ver comandos disponibles");
                break;
        }
        
        return true;
    }
    
    private void showKeyInstructions(CommandSender sender) {
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GOLD + "🎮 ═══ CONFIGURAR TECLAS X, C, V ═══");
        sender.sendMessage(ChatColor.YELLOW + "Para usar las teclas X, C, V:");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GRAY + "Después de configurar:");
        sender.sendMessage(ChatColor.GREEN + "• X = Habilidad 1 (1 kill)");
        sender.sendMessage(ChatColor.YELLOW + "• C = Habilidad 2 (3 kills)");
        sender.sendMessage(ChatColor.RED + "• V = Habilidad 3 (5 kills)");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.LIGHT_PURPLE + "💡 TIPS:");
        sender.sendMessage(ChatColor.GRAY + "• Puedes usar cualquier tecla que quieras");
        sender.sendMessage(ChatColor.GRAY + "• Solo cambia las asignaciones en controles");
        sender.sendMessage(ChatColor.GRAY + "• ¡El plugin detectará automáticamente!");
        sender.sendMessage(ChatColor.GOLD + "═══════════════════════════════════");
        sender.sendMessage("");
    }
    
    private void showHelp(CommandSender sender) {
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GOLD + "═══════ POWERRISE COMANDOS ═══════");
        sender.sendMessage(ChatColor.YELLOW + "/power" + ChatColor.GRAY + " - Ver tu poder actual");
        sender.sendMessage(ChatColor.YELLOW + "/power teclas" + ChatColor.GRAY + " - Instrucciones para configurar X, C, V");
        sender.sendMessage(ChatColor.YELLOW + "/power ver [jugador]" + ChatColor.GRAY + " - Ver poder de un jugador");
        sender.sendMessage(ChatColor.YELLOW + "/power help" + ChatColor.GRAY + " - Mostrar esta ayuda");
        
        if (sender.hasPermission("powerrise.admin")) {
            sender.sendMessage("");
            sender.sendMessage(ChatColor.RED + "═══ COMANDOS DE ADMIN ═══");
            sender.sendMessage(ChatColor.YELLOW + "/power admin help" + ChatColor.GRAY + " - Ayuda de admin");
            sender.sendMessage(ChatColor.YELLOW + "/power admin set <jugador> <poder>" + ChatColor.GRAY + " - Cambiar poder");
            sender.sendMessage(ChatColor.YELLOW + "/power admin kills <jugador> <cantidad>" + ChatColor.GRAY + " - Establecer kills");
            sender.sendMessage(ChatColor.YELLOW + "/power admin reset <jugador>" + ChatColor.GRAY + " - Resetear jugador");
            sender.sendMessage(ChatColor.YELLOW + "/power admin list" + ChatColor.GRAY + " - Listar todos los jugadores");
            sender.sendMessage(ChatColor.YELLOW + "/power reload" + ChatColor.GRAY + " - Recargar configuración");
        }
        
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GRAY + "🎮 Controles:");
        sender.sendMessage(ChatColor.GREEN + "X" + ChatColor.GRAY + " - Primera habilidad (1 kill)");
        sender.sendMessage(ChatColor.YELLOW + "C" + ChatColor.GRAY + " - Segunda habilidad (3 kills)");
        sender.sendMessage(ChatColor.RED + "V" + ChatColor.GRAY + " - Tercera habilidad (5 kills)");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.LIGHT_PURPLE + "💡 Usa " + ChatColor.YELLOW + "/power teclas" + ChatColor.LIGHT_PURPLE + " para configurar");
        sender.sendMessage(ChatColor.GOLD + "═══════════════════════════════════");
        sender.sendMessage("");
    }
    
    private void handleInfoCommand(CommandSender sender, String[] args) {
        if (args.length == 1) {
            if (sender instanceof Player) {
                showPlayerPower((Player) sender);
            } else {
                sender.sendMessage(ChatColor.RED + "Especifica un jugador: /power ver <jugador>");
            }
        } else {
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Jugador no encontrado: " + args[1]);
                return;
            }
            
            showPlayerPower(target, sender);
        }
    }
    
    private void handleAdminCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("powerrise.admin")) {
            sender.sendMessage(ChatColor.RED + "No tienes permisos para usar comandos de administrador.");
            return;
        }
        
        if (args.length == 1) {
            showAdminHelp(sender);
            return;
        }
        
        String adminSubCommand = args[1].toLowerCase();
        
        switch (adminSubCommand) {
            case "help":
            case "ayuda":
                showAdminHelp(sender);
                break;
                
            case "set":
            case "cambiar":
                handleSetPowerCommand(sender, args);
                break;
                
            case "kills":
                handleSetKillsCommand(sender, args);
                break;
                
            case "reset":
                handleResetPlayerCommand(sender, args);
                break;
                
            case "list":
            case "lista":
                handleListPlayersCommand(sender);
                break;
                
            default:
                sender.sendMessage(ChatColor.RED + "Subcomando de admin desconocido: " + adminSubCommand);
                showAdminHelp(sender);
                break;
        }
    }
    
    private void showAdminHelp(CommandSender sender) {
        sender.sendMessage("");
        sender.sendMessage(ChatColor.RED + "═══════ POWERRISE ADMIN ═══════");
        sender.sendMessage(ChatColor.YELLOW + "/power admin set <jugador> <poder>" + ChatColor.GRAY + " - Cambiar poder de jugador");
        sender.sendMessage(ChatColor.YELLOW + "/power admin kills <jugador> <cantidad>" + ChatColor.GRAY + " - Establecer kills");
        sender.sendMessage(ChatColor.YELLOW + "/power admin reset <jugador>" + ChatColor.GRAY + " - Resetear completamente");
        sender.sendMessage(ChatColor.YELLOW + "/power admin list" + ChatColor.GRAY + " - Listar todos los jugadores");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GRAY + "Poderes disponibles:");
        for (PowerType power : PowerType.values()) {
            sender.sendMessage(ChatColor.GRAY + "• " + power.name() + " (" + power.getFormattedName() + ChatColor.GRAY + ")");
        }
        sender.sendMessage(ChatColor.RED + "═══════════════════════════════");
        sender.sendMessage("");
    }
    
    private void handleSetPowerCommand(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(ChatColor.RED + "Uso: /power admin set <jugador> <poder>");
            sender.sendMessage(ChatColor.YELLOW + "Poderes: " + Arrays.stream(PowerType.values())
                    .map(Enum::name)
                    .collect(Collectors.joining(", ")));
            return;
        }
        
        Player target = Bukkit.getPlayer(args[2]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Jugador no encontrado: " + args[2]);
            return;
        }
        
        PowerType newPower;
        try {
            newPower = PowerType.valueOf(args[3].toUpperCase());
        } catch (IllegalArgumentException e) {
            sender.sendMessage(ChatColor.RED + "Poder inválido: " + args[3]);
            sender.sendMessage(ChatColor.YELLOW + "Poderes disponibles: " + 
                    Arrays.stream(PowerType.values()).map(Enum::name).collect(Collectors.joining(", ")));
            return;
        }
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target);
        PowerType oldPower = data.getCurrentPower();

                switch (oldPower) {
            case EARTH:
                target.removePotionEffect(PotionEffectType.FAST_DIGGING);
                break;
            case SHADOW:
                target.removePotionEffect(PotionEffectType.SPEED);
                break;
        }

        if (newPower != null) {
            switch (newPower) {
                case EARTH:
                    target.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, Integer.MAX_VALUE, 0, false, false));
                    break;
                case SHADOW:
                    target.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, false, false));
                    break;
            }
        }
        
        data.setCurrentPower(newPower);
        plugin.getPlayerDataManager().savePlayerData(data);
        
        sender.sendMessage(ChatColor.GREEN + "✅ Poder de " + target.getName() + " cambiado de " + 
                (oldPower != null ? oldPower.getFormattedName() : "§7Ninguno") + 
                ChatColor.GREEN + " a " + newPower.getFormattedName());
        
        target.sendMessage(ChatColor.YELLOW + "⚡ Un administrador ha cambiado tu poder a " + newPower.getFormattedName());
    }
    
    private void handleSetKillsCommand(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(ChatColor.RED + "Uso: /power admin kills <jugador> <cantidad>");
            return;
        }
        
        Player target = Bukkit.getPlayer(args[2]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Jugador no encontrado: " + args[2]);
            return;
        }
        
        int kills;
        try {
            kills = Integer.parseInt(args[3]);
            if (kills < 0) {
                sender.sendMessage(ChatColor.RED + "La cantidad de kills no puede ser negativa.");
                return;
            }
        } catch (NumberFormatException e) {
            sender.sendMessage(ChatColor.RED + "Cantidad inválida: " + args[3]);
            return;
        }
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target);
        int oldKills = data.getTotalKills();
        
        // Establecer kills manualmente
        data.resetKills();
        for (int i = 0; i < kills; i++) {
            data.addKill();
        }
        
        plugin.getPlayerDataManager().savePlayerData(data);
        
        sender.sendMessage(ChatColor.GREEN + "✅ Kills de " + target.getName() + " cambiadas de " + 
                oldKills + " a " + kills);
        
        target.sendMessage(ChatColor.YELLOW + "⚡ Un administrador ha establecido tus kills a " + kills);
    }
    
    private void handleResetPlayerCommand(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Uso: /power admin reset <jugador>");
            return;
        }
        
        Player target = Bukkit.getPlayer(args[2]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Jugador no encontrado: " + args[2]);
            return;
        }
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target);
        PowerType oldPower = data.getCurrentPower();
        
        // Asignar nuevo poder aleatorio
        PowerType newPower = PowerType.getRandomPower(oldPower);
        data.setCurrentPower(newPower);
        data.resetKills();
        
        // Limpiar todos los cooldowns
        data.getCooldowns().clear();

        if (!(sender instanceof Player)) {
    sender.sendMessage("Este comando solo puede ser usado por jugadores.");
    return;
}
Player player = (Player) sender;

                switch (oldPower) {
            case EARTH:
                player.removePotionEffect(PotionEffectType.FAST_DIGGING);
                break;
            case SHADOW:
                player.removePotionEffect(PotionEffectType.SPEED);
                break;
        }

        if (newPower != null) {
            switch (newPower) {
                case EARTH:
                    player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, Integer.MAX_VALUE, 0, false, false));
                    break;
                case SHADOW:
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, false, false));
                    break;
            }
        }
        
        plugin.getPlayerDataManager().savePlayerData(data);
        
        sender.sendMessage(ChatColor.GREEN + "✅ Jugador " + target.getName() + " reseteado completamente");
        sender.sendMessage(ChatColor.GRAY + "Poder anterior: " + (oldPower != null ? oldPower.getFormattedName() : "§7Ninguno"));
        sender.sendMessage(ChatColor.GRAY + "Nuevo poder: " + newPower.getFormattedName());
        
        target.sendMessage(ChatColor.YELLOW + "⚡ Un administrador ha reseteado tu cuenta");
        target.sendMessage(ChatColor.GRAY + "Tu nuevo poder es: " + newPower.getFormattedName());
    }
    
    private void handleListPlayersCommand(CommandSender sender) {
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GOLD + "═══════ JUGADORES POWERRISE ═══════");
        
        int totalPlayers = 0;
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
            PowerType power = data.getCurrentPower();
            
            if (power != null) {
                sender.sendMessage(ChatColor.WHITE + player.getName() + ChatColor.GRAY + " - " + 
                        power.getFormattedName() + ChatColor.GRAY + " (" + data.getTotalKills() + " kills)");
                totalPlayers++;
            }
        }
        
        if (totalPlayers == 0) {
            sender.sendMessage(ChatColor.GRAY + "No hay jugadores con poderes actualmente.");
        } else {
            sender.sendMessage("");
            sender.sendMessage(ChatColor.GRAY + "Total: " + totalPlayers + " jugadores");
        }
        
        sender.sendMessage(ChatColor.GOLD + "═══════════════════════════════════");
        sender.sendMessage("");
    }
    
    private void handleReloadCommand(CommandSender sender) {
        if (!sender.hasPermission("powerrise.admin")) {
            sender.sendMessage(ChatColor.RED + "No tienes permisos para recargar la configuración.");
            return;
        }
        
        try {
            plugin.reloadConfig();
            plugin.getPlayerDataManager().saveAllData();
            
            sender.sendMessage(ChatColor.GREEN + "✅ Configuración de PowerRise recargada correctamente");
        } catch (Exception e) {
            sender.sendMessage(ChatColor.RED + "❌ Error al recargar la configuración: " + e.getMessage());
        }
    }
    
    private void showPlayerPower(Player player) {
        showPlayerPower(player, player);
    }
    
    private void showPlayerPower(Player target, CommandSender sender) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target);
        PowerType power = data.getCurrentPower();
        
        if (power == null) {
            sender.sendMessage(ChatColor.RED + target.getName() + " no tiene un poder asignado.");
            return;
        }
        
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GOLD + "═══ INFORMACIÓN DE PODER ═══");
        sender.sendMessage(ChatColor.WHITE + "Jugador: " + ChatColor.YELLOW + target.getName());
        sender.sendMessage(ChatColor.WHITE + "Poder: " + power.getFormattedName());
        sender.sendMessage(ChatColor.WHITE + "Kills: " + ChatColor.GREEN + data.getTotalKills());
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GRAY + "Habilidades:");
        
        String powerName = power.name().toLowerCase();
        sender.sendMessage((data.hasAbilityUnlocked(powerName + "_ability_1") ? ChatColor.GREEN + "✓" : ChatColor.RED + "✗") + 
                ChatColor.GRAY + " X - Primera habilidad (1 kill)");
        sender.sendMessage((data.hasAbilityUnlocked(powerName + "_ability_2") ? ChatColor.GREEN + "✓" : ChatColor.RED + "✗") + 
                ChatColor.GRAY + " C - Segunda habilidad (3 kills)");
        sender.sendMessage((data.hasAbilityUnlocked(powerName + "_ability_3") ? ChatColor.GREEN + "✓" : ChatColor.RED + "✗") + 
                ChatColor.GRAY + " V - Tercera habilidad (5 kills)");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.LIGHT_PURPLE + "💡 Usa " + ChatColor.YELLOW + "/power teclas" + ChatColor.LIGHT_PURPLE + " para configurar controles");
        sender.sendMessage(ChatColor.GOLD + "═══════════════════════════════");
        sender.sendMessage("");
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            completions.addAll(Arrays.asList("help", "teclas", "ver", "info"));
            if (sender.hasPermission("powerrise.admin")) {
                completions.addAll(Arrays.asList("admin", "reload"));
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("ver") || args[0].equalsIgnoreCase("info")) {
                return Bukkit.getOnlinePlayers().stream()
                        .map(Player::getName)
                        .collect(Collectors.toList());
            } else if (args[0].equalsIgnoreCase("admin") && sender.hasPermission("powerrise.admin")) {
                completions.addAll(Arrays.asList("help", "set", "kills", "reset", "list"));
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("admin") && sender.hasPermission("powerrise.admin")) {
            if (Arrays.asList("set", "kills", "reset").contains(args[1].toLowerCase())) {
                return Bukkit.getOnlinePlayers().stream()
                        .map(Player::getName)
                        .collect(Collectors.toList());
            }
        } else if (args.length == 4 && args[0].equalsIgnoreCase("admin") && sender.hasPermission("powerrise.admin")) {
            if (args[1].equalsIgnoreCase("set")) {
                return Arrays.stream(PowerType.values())
                        .map(Enum::name)
                        .collect(Collectors.toList());
            }
        }
        
        return completions.stream()
                .filter(s -> s.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                .collect(Collectors.toList());
    }
}
