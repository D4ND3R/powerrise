package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.managers.KeyItemManager;
import com.powerrise.managers.PowerManager;
import com.powerrise.powers.PowerType;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.ItemStack;

public class KeyPressListener implements Listener {
    private final PowerRisePlugin plugin;
    private final PowerManager powerManager;
    
    public KeyPressListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
        this.powerManager = plugin.getPowerManager();
    }
    
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        
        // Solo clic derecho
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        
        // Verificar si es un item de habilidad
        if (!KeyItemManager.isKeyItem(item)) return;
        
        event.setCancelled(true); // Cancelar la acción normal
        
        // Determinar qué habilidad activar
        if (KeyItemManager.isXKeyItem(item)) {
            activateAbility1(player); // Habilidad X
            player.sendMessage(ChatColor.GREEN + "🔥 Tecla X presionada");
        } else if (KeyItemManager.isCKeyItem(item)) {
            activateAbility2(player); // Habilidad C
            player.sendMessage(ChatColor.YELLOW + "⚡ Tecla C presionada");
        } else if (KeyItemManager.isVKeyItem(item)) {
            activateAbility3(player); // Habilidad V
            player.sendMessage(ChatColor.RED + "💀 Tecla V presionada");
        }
    }
    
    // Prevenir que tiren los items de habilidades
    @EventHandler
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        ItemStack item = event.getItemDrop().getItemStack();
        if (KeyItemManager.isKeyItem(item)) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(ChatColor.RED + "❌ No puedes tirar los items de habilidades!");
        }
    }
    
    // Prevenir que muevan los items de habilidades en el inventario
@EventHandler
public void onInventoryClick(InventoryClickEvent event) {
    ItemStack item = event.getCurrentItem();

    // Asegurarse que el ítem no sea null o aire
    if (item == null || item.getType().isAir()) return;

    // Verificar si es un ítem de habilidad
    if (KeyItemManager.isKeyItem(item)) {

        // Bloquear cualquier intento de moverlo fuera de la hotbar (slots 0-8)
        if (event.getSlot() < 9 && !event.isShiftClick()) {
            return; // Permitir movimientos normales dentro de la hotbar
        }

        // Cancelar el movimiento, incluyendo shift-click y arrastre
        event.setCancelled(true);
        event.getWhoClicked().sendMessage(ChatColor.RED + "❌ No puedes mover los ítems de habilidades!");
    }
}

@EventHandler
public void onInventoryDrag(InventoryClickEvent event) {
    ItemStack item = event.getCurrentItem();
    if (item != null && KeyItemManager.isKeyItem(item)) {
        event.setCancelled(true);
    }
}

    
    private void activateAbility1(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        PowerType power = data.getCurrentPower();
        
        if (power == null) {
            player.sendMessage(ChatColor.RED + "❌ No tienes un poder asignado!");
            return;
        }
        
        switch (power) {
            case FIRE:
                powerManager.activateFireAbility1(player);
                break;
            case EARTH:
                powerManager.activateEarthAbility1(player);
                break;
            case SHADOW:
                powerManager.activateShadowAbility1(player);
                break;
            case SKY:
                powerManager.activateSkyAbility1(player);
                break;
        }
    }
    
    private void activateAbility2(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        PowerType power = data.getCurrentPower();
        
        if (power == null) return;
        
        switch (power) {
            case FIRE:
                powerManager.activateFireAbility2(player);
                break;
            case EARTH:
                powerManager.activateEarthAbility2(player);
                break;
            case SHADOW:
                powerManager.activateShadowAbility2(player);
                break;
            case SKY:
                powerManager.activateSkyAbility2(player);
                break;
        }
    }
    
    private void activateAbility3(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        PowerType power = data.getCurrentPower();
        
        if (power == null) return;
        
        switch (power) {
            case FIRE:
                powerManager.activateFireAbility3(player);
                break;
            case EARTH:
                powerManager.activateEarthAbility3(player);
                break;
            case SHADOW:
                powerManager.activateShadowAbility3(player);
                break;
            case SKY:
                powerManager.activateSkyAbility3(player);
                break;
        }
    }
}
