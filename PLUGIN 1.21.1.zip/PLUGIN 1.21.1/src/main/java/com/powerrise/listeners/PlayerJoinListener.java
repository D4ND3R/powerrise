package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.powers.PowerType;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.Bukkit;

import java.io.File;

public class PlayerJoinListener implements Listener {
    private final PowerRisePlugin plugin;
    
    public PlayerJoinListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
@EventHandler
public void onPlayerJoin(PlayerJoinEvent event) {
    Player player = event.getPlayer();
    PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);

    boolean isFirstTime = !player.hasPlayedBefore();

    PowerType randomPower = PowerType.getRandomPowerN();

    if (isFirstTime) {
data.setCurrentPower(randomPower);
plugin.getPlayerDataManager().savePlayerData(data);

plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
    plugin.getTitleManager().showPowerRoulette(player, randomPower);
}, 60L);
    } else {
        player.sendMessage("");
        player.sendMessage(ChatColor.GOLD + "✦ Bienvenido de vuelta a PowerRise ✦");
        player.sendMessage(ChatColor.WHITE + "Tu poder: " + data.getCurrentPower().getFormattedName());
        player.sendMessage(ChatColor.GREEN + "Kills: " + data.getTotalKills());
        player.sendMessage("");
    }

 Bukkit.getScheduler().runTaskLater(plugin, () -> {
        if (!ModMessageListener.hasMod(player)) {
            plugin.getKeyItemManager().giveKeyItems(player);
        } else {
            plugin.getKeyItemManager().removeKeyItems(player);
        }
    }, 20L);

    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
        showKeyInstructions(player);
    }, 60L);

    applyPassiveEffects(player, data.getCurrentPower());
    plugin.getHUDManager().startHUD(player);
}

    private void showKeyInstructions(Player player) {
        player.sendMessage("");
        player.sendMessage(ChatColor.GOLD + "🎮 ═══ CONFIGURAR TECLAS X, C, V ═══");
        player.sendMessage(ChatColor.YELLOW + "Para usar las teclas X, C, V:");
        player.sendMessage("");
        player.sendMessage(ChatColor.GREEN + "• X = Habilidad 1 (1 kill)");
        player.sendMessage(ChatColor.YELLOW + "• C = Habilidad 2 (3 kills)");
        player.sendMessage(ChatColor.RED + "• V = Habilidad 3 (5 kills)");
        player.sendMessage(ChatColor.GOLD + "═══════════════════════════════════");
        player.sendMessage("");
    }
    
    private void applyPassiveEffects(Player player, PowerType power) {
        if (power == null) return;
        
        switch (power) {
            case FIRE:
                // Inmunidad al fuego (se maneja en EntityDamageListener)
                break;
            case EARTH:
                // Haste 1 infinito
                player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, Integer.MAX_VALUE, 0, false, false));
                break;
            case SHADOW:
                // Velocidad 1 infinita
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, false, false));
                break;
            case SKY:
                // No tomar daño de caída (se maneja en EntityDamageListener)
                break;
        }
    }
}
