package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class FireAuraListener implements Listener {

    private final PowerRisePlugin plugin;

    public FireAuraListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            Player damager = (Player) event.getDamager();
            PlayerData data = plugin.getPlayerDataManager().getPlayerData(damager);

            if (data.isOnCooldown("fire_aura_active")) {
                if (event.getEntity() instanceof LivingEntity && !event.getEntity().equals(damager)) {
                    ((LivingEntity) event.getEntity()).setFireTicks(100); // 5s de fuego
                }
            }
        }
    }
}
