package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.managers.PowerManager;
import com.powerrise.powers.PowerType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class EntityDamageListener implements Listener {
    private final PowerRisePlugin plugin;
    private final PowerManager powerManager;
    
    public EntityDamageListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
        this.powerManager = plugin.getPowerManager();
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        
        Player player = (Player) event.getEntity();
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        PowerType power = data.getCurrentPower();
        
        if (power == null) return;
        
        // Efectos pasivos defensivos (usando nombres no calificados)
        switch (power) {
            case FIRE:
                // Inmunidad al fuego
                if (event.getCause() == EntityDamageEvent.DamageCause.FIRE ||
                    event.getCause() == EntityDamageEvent.DamageCause.FIRE_TICK ||
                    event.getCause() == EntityDamageEvent.DamageCause.LAVA) {
                    event.setCancelled(true);
                }
                break;
                
            case EARTH:
                // Escudo de tierra activo
                if (powerManager.hasEarthShield(data)) {
                    event.setDamage(event.getDamage() * 0.3); // 70% menos daño
                }
                break;
                
            case SHADOW:
                // Sin efectos pasivos defensivos especiales
                break;
                
            case SKY:
                // No daño de caída
                if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
                    event.setCancelled(true);
                }
                break;
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player) || !(event.getEntity() instanceof Player)) {
            return;
        }
        
        Player attacker = (Player) event.getDamager();
        Player victim = (Player) event.getEntity();
        
        PlayerData attackerData = plugin.getPlayerDataManager().getPlayerData(attacker);
        PowerType attackerPower = attackerData.getCurrentPower();
        
        // Efectos del atacante (usando nombres no calificados)
        if (attackerPower != null) {
            switch (attackerPower) {
                case FIRE:
                    // Aura de fuego activa
                    if (powerManager.hasFireAura(attackerData)) {
                        victim.setFireTicks(100); // 5 segundos de fuego
                    }
                    break;
                    
                case EARTH:
                    // Sin efectos especiales en ataque
                    break;
                    
                case SHADOW:
                    // Sin efectos especiales en ataque
                    break;
                    
                case SKY:
                    // Rayos cada 3 ataques
                    if (powerManager.hasSkyLightning(attackerData)) {
                        powerManager.handleSkyLightningAttack(attacker, victim);
                    }
                    break;
            }
        }
    }
}
