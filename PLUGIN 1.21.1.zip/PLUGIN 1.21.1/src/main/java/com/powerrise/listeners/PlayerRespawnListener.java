package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.powers.PowerType;

import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.entity.Player;

public class PlayerRespawnListener implements Listener {
    private final PowerRisePlugin plugin;
    
    public PlayerRespawnListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        
        // Dar items de habilidades después del respawn
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!ModMessageListener.hasMod(player)) {
    plugin.getKeyItemManager().giveKeyItems(player);
                }
        }, 20L); // 1 segundo después

                plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            PlayerData data = plugin.getPlayerDataManager().getPlayerData(event.getPlayer());
            PowerType power = data.getCurrentPower();
            if (power != null) {
                switch (power) {
                    case EARTH:
                        event.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, Integer.MAX_VALUE, 0, false, false));
                        break;
                    case SHADOW:
                        event.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, false, false));
                        break;
                }
            }
        }, 20L);
    }
}
