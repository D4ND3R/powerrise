package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class PowerEvents implements Listener {
    private final PowerRisePlugin plugin;

    public PowerEvents(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }

    // ⚡ Sky Lightning Attack
    @EventHandler
    public void onPlayerAttack(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player attacker && event.getEntity() instanceof Player victim) {
            plugin.getPowerManager().handleSkyLightningAttack(attacker, victim);
        }
    }

    // 🔥 Prevent fireball self-damage
    @EventHandler
    public void onFireballHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Fireball fireball)) return;
        if (!(fireball.getShooter() instanceof Player shooter)) return;
        if (!(event.getEntity() instanceof Player target)) return;

        if (shooter.equals(target)) {
            event.setCancelled(true);
        }
    }

    // 💥 Prevent explosion self-damage
    @EventHandler
    public void onExplosionSelfDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player damager)) return;
        if (!(event.getEntity() instanceof Player victim)) return;

        if (damager.equals(victim) && event.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
            event.setCancelled(true);
        }
    }
}
