package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.managers.CraftingManager;
import com.powerrise.powers.PowerType;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;


public class PlayerInteractListener implements Listener {
    private final PowerRisePlugin plugin;
    
    public PlayerInteractListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        
        if (item == null) return;
        
        // Verificar si es la Piedra del Renacer
        if (CraftingManager.isRebirthStone(item) && 
            (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK)) {
            
            event.setCancelled(true);
            
            // Debug message
            player.sendMessage(ChatColor.YELLOW + "🔧 Usando Piedra del Renacer...");
            
            useRebirthStone(player, item);
            return;
        }
    }
    
    private void useRebirthStone(Player player, ItemStack stone) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        PowerType oldPower = data.getCurrentPower();
        
        if (oldPower == null) {
            player.sendMessage(ChatColor.RED + "❌ No tienes un poder para cambiar!");
            return;
        }
        
        // Generar nuevo poder (diferente al actual)
        PowerType newPower = PowerType.getRandomPower(oldPower);
        
        // Cambiar poder y resetear kills
        data.setCurrentPower(newPower);
        data.resetKills();
        
        // Limpiar cooldowns
        data.getCooldowns().clear();

        switch (oldPower) {
            case EARTH:
                player.removePotionEffect(PotionEffectType.FAST_DIGGING);
                break;
            case SHADOW:
                player.removePotionEffect(PotionEffectType.SPEED);
                break;
        }

        if (newPower != null) {
            switch (newPower) {
                case EARTH:
                    player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, Integer.MAX_VALUE, 0, false, false));
                    break;
                case SHADOW:
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, false, false));
                    break;
            }
        }
        
        // Guardar datos
        plugin.getPlayerDataManager().savePlayerData(data);
        
        // Consumir item
        if (stone.getAmount() > 1) {
            stone.setAmount(stone.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
        
        // Efectos visuales y sonoros
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.8f);
        
        // Mensaje de cambio
        player.sendMessage("");
        player.sendMessage(ChatColor.LIGHT_PURPLE + "✨═══ PODER CAMBIADO ═══✨");
        player.sendMessage(ChatColor.GRAY + "Poder anterior: " + oldPower.getFormattedName());
        player.sendMessage(ChatColor.WHITE + "Nuevo poder: " + newPower.getFormattedName());
        player.sendMessage(ChatColor.RED + "⚠ Tus kills se han reiniciado a 0");
        player.sendMessage("");
        
        // Mostrar título
        player.sendTitle(
            ChatColor.LIGHT_PURPLE + "✨ PODER CAMBIADO ✨",
            newPower.getFormattedName(),
            10, 60, 20
        );
    }
}
