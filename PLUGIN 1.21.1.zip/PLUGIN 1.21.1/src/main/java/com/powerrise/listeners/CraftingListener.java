package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import com.powerrise.managers.CraftingManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.ItemStack;

public class CraftingListener implements Listener {
    private final PowerRisePlugin plugin;
    
    public CraftingListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onCraftItem(CraftItemEvent event) {
        ItemStack result = event.getRecipe().getResult();
        
        if (CraftingManager.isRebirthStone(result)) {
            event.getWhoClicked().sendMessage("§d✨ ¡Has creado una Piedra del Renacer! ✨");
            event.getWhoClicked().sendMessage("§7Úsala con clic derecho para cambiar tu poder.");
        }
    }
}
