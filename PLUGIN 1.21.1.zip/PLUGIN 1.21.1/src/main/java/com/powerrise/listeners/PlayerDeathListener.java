package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.managers.PowerManager;
import com.powerrise.powers.PowerType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import com.powerrise.managers.KeyItemManager;


public class PlayerDeathListener implements Listener {
    private final PowerRisePlugin plugin;
    private final PowerManager powerManager;
    
    public PlayerDeathListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
        this.powerManager = plugin.getPowerManager();
    }
    
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        Player player = event.getEntity();
        event.getDrops().removeIf(KeyItemManager::isKeyItem);
        
        // Solo contar kills de jugadores
        if (killer == null || killer.equals(victim)) return;
        
        PlayerData killerData = plugin.getPlayerDataManager().getPlayerData(killer);
        int previousKills = killerData.getTotalKills();
        killerData.addKill();
        int newKills = killerData.getTotalKills();
        
        // Guardar datos
        plugin.getPlayerDataManager().savePlayerData(killerData);
        
        // Verificar si desbloqueó nueva habilidad
        if (newKills == 1 || newKills == 3 || newKills == 5) {
            plugin.getMessageManager().sendKillUnlock(killer, newKills);
        }
        
        // Aplicar efectos según el poder (usando nombres no calificados)
        PowerType power = killerData.getCurrentPower();
        if (power != null) {
            switch (power) {
                case FIRE:
                    // No hay efectos automáticos en kill para fuego
                    break;
                    
                case EARTH:
                    // No hay efectos automáticos en kill para tierra
                    break;
                    
                case SHADOW:
                    // No hay efectos automáticos en kill para sombras
                    break;
                    
                case SKY:
                    // No hay efectos automáticos en kill para cielo
                    break;
            }
        }
    }
}
