package com.powerrise.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.messaging.PluginMessageListener;
import com.powerrise.PowerRisePlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ModMessageListener implements PluginMessageListener, Listener {
    private static final Set<UUID> playersWithMod = new HashSet<>();
    private final PowerRisePlugin plugin;
    
    public ModMessageListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (channel.equals("powerrise:mod")) {
            playersWithMod.add(player.getUniqueId());
            plugin.getLogger().info("Player " + player.getName() + " has PowerRise mod installed");
            
            // Optional: Send a welcome message or enable mod-specific features
            // player.sendMessage("§aPowerRise mod detected! All features enabled.");
        }
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        removePlayer(event.getPlayer());
    }
    
    public static boolean hasMod(Player player) {
        return playersWithMod.contains(player.getUniqueId());
    }
    
    public static void removePlayer(Player player) {
        playersWithMod.remove(player.getUniqueId());
    }
    
    public static Set<UUID> getPlayersWithMod() {
        return new HashSet<>(playersWithMod);
    }
    
    public static int getModPlayerCount() {
        return playersWithMod.size();
    }
}