package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.managers.PowerManager;
import com.powerrise.powers.PowerType;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;

public class ClientPacketListener implements PluginMessageListener {
    private final PowerRisePlugin plugin;
    private final PowerManager powerManager;
    
    public ClientPacketListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
        this.powerManager = plugin.getPowerManager();
    }
    
    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (!channel.equals("powerrise:abilities")) return;
        
        String ability = new String(message);
        
        switch (ability) {
            case "ability_x":
                activateAbility1(player);
                player.sendMessage(ChatColor.GREEN + "🔥 TECLA X LITERAL PRESIONADA!");
                break;
            case "ability_c":
                activateAbility2(player);
                player.sendMessage(ChatColor.YELLOW + "⚡ TECLA C LITERAL PRESIONADA!");
                break;
            case "ability_v":
                activateAbility3(player);
                player.sendMessage(ChatColor.RED + "💀 TECLA V LITERAL PRESIONADA!");
                break;
        }
    }
    
    private void activateAbility1(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        PowerType power = data.getCurrentPower();
        
        if (power == null) return;
        
        switch (power) {
            case FIRE:
                powerManager.activateFireAbility1(player);
                break;
            case EARTH:
                powerManager.activateEarthAbility1(player);
                break;
            case SHADOW:
                powerManager.activateShadowAbility1(player);
                break;
            case SKY:
                powerManager.activateSkyAbility1(player);
                break;
        }
    }
    
    private void activateAbility2(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        PowerType power = data.getCurrentPower();
        
        if (power == null) return;
        
        switch (power) {
            case FIRE:
                powerManager.activateFireAbility2(player);
                break;
            case EARTH:
                powerManager.activateEarthAbility2(player);
                break;
            case SHADOW:
                powerManager.activateShadowAbility2(player);
                break;
            case SKY:
                powerManager.activateSkyAbility2(player);
                break;
        }
    }
    
    private void activateAbility3(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        PowerType power = data.getCurrentPower();
        
        if (power == null) return;
        
        switch (power) {
            case FIRE:
                powerManager.activateFireAbility3(player);
                break;
            case EARTH:
                powerManager.activateEarthAbility3(player);
                break;
            case SHADOW:
                powerManager.activateShadowAbility3(player);
                break;
            case SKY:
                powerManager.activateSkyAbility3(player);
                break;
        }
    }
}
