package com.powerrise.listeners;

import com.powerrise.PowerRisePlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerQuitListener implements Listener {
    private final PowerRisePlugin plugin;
    
    public PlayerQuitListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        // Guardar datos del jugador
        plugin.getPlayerDataManager().unloadPlayerData(player.getUniqueId());
        
        // Limpiar efectos activos
        plugin.getPowerManager().cleanupPlayer(player);

        ModMessageListener.removePlayer(event.getPlayer());
    }
}
