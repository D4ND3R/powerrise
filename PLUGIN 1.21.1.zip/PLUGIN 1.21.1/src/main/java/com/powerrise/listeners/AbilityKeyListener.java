package com.powerrise.listeners;

import java.nio.ByteBuffer;
import com.powerrise.PowerRisePlugin;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;
import com.powerrise.data.PlayerData;
import com.powerrise.powers.PowerType;

public class AbilityKeyListener implements PluginMessageListener {
    private final PowerRisePlugin plugin;
    
    public AbilityKeyListener(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        // Check if this is the ability channel
        if (!channel.equals("powerrise:ability")) {
            return;
        }
        
        // Add null checks for safety
        if (message == null || message.length < 4) {
            plugin.getLogger().warning("Received invalid ability packet from " + player.getName());
            return;
        }
        
        try {
            PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
            if (data == null) {
                plugin.getLogger().warning("No player data found for " + player.getName());
                return;
            }
            
            PowerType power = data.getCurrentPower();
            if (power == null) {
                plugin.getLogger().warning("Player " + player.getName() + " has no power assigned");
                return;
            }
            
            int abilityNumber = ByteBuffer.wrap(message).getInt();
            plugin.getLogger().info("Player " + player.getName() + " activated ability " + abilityNumber + " with power " + power);
            
            switch (abilityNumber) {
                case 1:
                    activateAbility1(player, power);
                    break;
                case 2:
                    activateAbility2(player, power);
                    break;
                case 3:
                    activateAbility3(player, power);
                    break;
                default:
                    plugin.getLogger().warning("Unknown ability number: " + abilityNumber + " from player " + player.getName());
            }
        } catch (Exception e) {
            plugin.getLogger().severe("Error processing ability packet from " + player.getName() + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void activateAbility1(Player player, PowerType power) {
        switch (power) {
            case FIRE:
                plugin.getPowerManager().activateFireAbility1(player);
                break;
            case EARTH:
                plugin.getPowerManager().activateEarthAbility1(player);
                break;
            case SHADOW:
                plugin.getPowerManager().activateShadowAbility1(player);
                break;
            case SKY:
                plugin.getPowerManager().activateSkyAbility1(player);
                break;
            default:
                plugin.getLogger().warning("Unknown power type: " + power + " for player " + player.getName());
        }
    }
    
    private void activateAbility2(Player player, PowerType power) {
        switch (power) {
            case FIRE:
                plugin.getPowerManager().activateFireAbility2(player);
                break;
            case EARTH:
                plugin.getPowerManager().activateEarthAbility2(player);
                break;
            case SHADOW:
                plugin.getPowerManager().activateShadowAbility2(player);
                break;
            case SKY:
                plugin.getPowerManager().activateSkyAbility2(player);
                break;
            default:
                plugin.getLogger().warning("Unknown power type: " + power + " for player " + player.getName());
        }
    }
    
    private void activateAbility3(Player player, PowerType power) {
        switch (power) {
            case FIRE:
                plugin.getPowerManager().activateFireAbility3(player);
                break;
            case EARTH:
                plugin.getPowerManager().activateEarthAbility3(player);
                break;
            case SHADOW:
                plugin.getPowerManager().activateShadowAbility3(player);
                break;
            case SKY:
                plugin.getPowerManager().activateSkyAbility3(player);
                break;
            default:
                plugin.getLogger().warning("Unknown power type: " + power + " for player " + player.getName());
        }
    }
}