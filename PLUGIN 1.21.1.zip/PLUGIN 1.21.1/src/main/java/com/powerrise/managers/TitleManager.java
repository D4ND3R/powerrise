package com.powerrise.managers;

import com.powerrise.PowerRisePlugin;
import com.powerrise.powers.PowerType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.Sound;

public class TitleManager {
    private final PowerRisePlugin plugin;
    
    public TitleManager(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    public void showPowerRoulette(Player player, PowerType finalPower) {
        new BukkitRunnable() {
            private int ticks = 0;
            private final int maxTicks = 60; // 3 segundos
            private PowerType currentPower = PowerType.FIRE;
            
            @Override
            public void run() {
                if (ticks >= maxTicks) {
                    // Mostrar poder final
player.sendTitle(finalPower.getColor() + "✦ " + finalPower.getFormattedName() + " ✦",
    "§7Tu poder ha sido elegido",
    20, 80, 20);
                    
                    // Sonido final épico
                    player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 0.8f);
                    
                    // Mostrar información del poder después
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        showPowerInfo(player, finalPower);
                    }, 100L);
                    
                    cancel();
                    return;
                }
                
                // Cambiar poder mostrado
                PowerType[] powers = PowerType.values();
                currentPower = powers[ticks % powers.length];
                
                // Calcular velocidad (más lento al final)
                int speed = Math.max(2, 10 - (ticks / 6));
                
                if (ticks % speed == 0) {
                    player.sendTitle(
                        currentPower.getColor() + "⟲ " + currentPower.getFormattedName() + " ⟲",
                        "§7Eligiendo tu poder...",
                        0, 15, 0
                    );
                    
                    // Sonido de cambio
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.5f);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
    
    private void showPowerInfo(Player player, PowerType power) {
        player.sendMessage("");
        player.sendMessage("§6═══════════════════════════════");
        player.sendMessage("§e    ✦ PODER ASIGNADO ✦");
        player.sendMessage("");
        player.sendMessage("§f  Tu poder es: " + power.getFormattedName());
        player.sendMessage("");
        player.sendMessage("§7  Controles:");
        player.sendMessage("§a  • X: Primera habilidad (1 kill)");
        player.sendMessage("§e  • C: Segunda habilidad (3 kills)");
        player.sendMessage("§c  • V: Tercera habilidad (5 kills)");
        player.sendMessage("");
        player.sendMessage("§f   Tu pasiva es: " + power.getPassive());
        player.sendMessage("");
        player.sendMessage("§7  Mata jugadores para desbloquear habilidades");
        player.sendMessage("§6═══════════════════════════════");
        player.sendMessage("");
    }
}
