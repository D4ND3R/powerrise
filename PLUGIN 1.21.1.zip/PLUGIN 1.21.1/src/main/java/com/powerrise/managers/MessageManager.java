package com.powerrise.managers;

import com.powerrise.PowerRisePlugin;
import com.powerrise.powers.PowerType;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MessageManager {
    private final PowerRisePlugin plugin;
    private FileConfiguration messages;
    
    public MessageManager(PowerRisePlugin plugin) {
        this.plugin = plugin;
        loadMessages();
    }
    
    private void loadMessages() {
        File messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        
        messages = YamlConfiguration.loadConfiguration(messagesFile);
        
        // Cargar valores por defecto
        InputStream defConfigStream = plugin.getResource("messages.yml");
        if (defConfigStream != null) {
            YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(defConfigStream));
            messages.setDefaults(defConfig);
        }
    }
    
    public String getMessage(String key) {
        return ChatColor.translateAlternateColorCodes('&', messages.getString(key, "Mensaje no encontrado: " + key));
    }
    
    public void sendPowerAssigned(Player player, PowerType power) {
        String message = getMessage("power-assigned")
            .replace("{power}", power.getFormattedName())
            .replace("{player}", player.getName());
        
        player.sendMessage("");
        player.sendMessage(ChatColor.GOLD + "═══════════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "    🌟 PODER ASIGNADO 🌟");
        player.sendMessage("");
        player.sendMessage(ChatColor.WHITE + "  Tu poder es: " + power.getFormattedName());
        player.sendMessage("");
        player.sendMessage(ChatColor.GRAY + "  Mata jugadores para desbloquear habilidades:");
        player.sendMessage(ChatColor.GREEN + "  • 1 Kill: Primera habilidad");
        player.sendMessage(ChatColor.YELLOW + "  • 3 Kills: Segunda habilidad");
        player.sendMessage(ChatColor.RED + "  • 5 Kills: Habilidad definitiva");
        player.sendMessage("");
        player.sendMessage(ChatColor.GOLD + "═══════════════════════════════");
        player.sendMessage("");
    }
    
    public void sendKillUnlock(Player player, int kills) {
        String abilityLevel = "";
        ChatColor color = ChatColor.WHITE;
        
        switch (kills) {
            case 1:
                abilityLevel = "PRIMERA";
                color = ChatColor.GREEN;
                break;
            case 3:
                abilityLevel = "SEGUNDA";
                color = ChatColor.YELLOW;
                break;
            case 5:
                abilityLevel = "DEFINITIVA";
                color = ChatColor.RED;
                break;
        }
        
        if (!abilityLevel.isEmpty()) {
            player.sendMessage("");
            player.sendMessage(color + "🎉 ¡HABILIDAD DESBLOQUEADA! 🎉");
            player.sendMessage(color + "Has desbloqueado tu " + abilityLevel + " habilidad");
            player.sendMessage(ChatColor.GRAY + "Kills totales: " + kills);
            player.sendMessage("");
        }
    }
    
    public void sendPowerChanged(Player player, PowerType oldPower, PowerType newPower) {
        player.sendMessage("");
        player.sendMessage(ChatColor.LIGHT_PURPLE + "✨ PODER CAMBIADO ✨");
        player.sendMessage(ChatColor.GRAY + "Poder anterior: " + oldPower.getFormattedName());
        player.sendMessage(ChatColor.WHITE + "Nuevo poder: " + newPower.getFormattedName());
        player.sendMessage(ChatColor.RED + "Tus kills se han reiniciado a 0");
        player.sendMessage("");
    }
}
