package com.powerrise.managers;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.powers.PowerType;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerDataManager {
    private final PowerRisePlugin plugin;
    private final Map<UUID, PlayerData> playerDataCache;
    private final File dataFolder;
    
    public PlayerDataManager(PowerRisePlugin plugin) {
        this.plugin = plugin;
        this.playerDataCache = new HashMap<>();
        this.dataFolder = new File(plugin.getDataFolder(), "playerdata");
        
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
    }
    
    public PlayerData getPlayerData(UUID uuid) {
        return playerDataCache.computeIfAbsent(uuid, this::loadPlayerData);
    }
    
    public PlayerData getPlayerData(Player player) {
        return getPlayerData(player.getUniqueId());
    }
    
    private PlayerData loadPlayerData(UUID uuid) {
        File playerFile = new File(dataFolder, uuid.toString() + ".yml");
        
        if (!playerFile.exists()) {
            // Nuevo jugador - asignar poder aleatorio
            PowerType randomPower = PowerType.getRandomPowerN();
            PlayerData newData = new PlayerData(uuid, randomPower, 0);
            savePlayerData(newData);
            return newData;
        }
        
        FileConfiguration config = YamlConfiguration.loadConfiguration(playerFile);
        
        PowerType power = null;
        String powerName = config.getString("power");
        if (powerName != null) {
            try {
                power = PowerType.valueOf(powerName);
            } catch (IllegalArgumentException e) {
                power = PowerType.getRandomPowerN();
            }
        }
        
        int kills = config.getInt("kills", 0);
        
        PlayerData data = new PlayerData(uuid, power, kills);
        
        // Cargar cooldowns
        if (config.contains("cooldowns")) {
            for (String key : config.getConfigurationSection("cooldowns").getKeys(false)) {
                long cooldownEnd = config.getLong("cooldowns." + key);
                if (cooldownEnd > System.currentTimeMillis()) {
                    data.setCooldown(key, cooldownEnd - System.currentTimeMillis());
                }
            }
        }
        
        return data;
    }
    
    public void savePlayerData(PlayerData data) {
        File playerFile = new File(dataFolder, data.getUuid().toString() + ".yml");
        FileConfiguration config = new YamlConfiguration();
        
        config.set("power", data.getCurrentPower().name());
        config.set("kills", data.getTotalKills());
        
        // Guardar cooldowns activos
        Map<String, Long> cooldowns = data.getCooldowns();
        for (Map.Entry<String, Long> entry : cooldowns.entrySet()) {
            if (entry.getValue() > System.currentTimeMillis()) {
                config.set("cooldowns." + entry.getKey(), entry.getValue());
            }
        }
        
        try {
            config.save(playerFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Error guardando datos del jugador " + data.getUuid() + ": " + e.getMessage());
        }
    }
    
    public void saveAllData() {
        for (PlayerData data : playerDataCache.values()) {
            savePlayerData(data);
        }
    }
    
    public void unloadPlayerData(UUID uuid) {
        PlayerData data = playerDataCache.remove(uuid);
        if (data != null) {
            savePlayerData(data);
        }
    }
}
