package com.powerrise.managers;

import com.powerrise.PowerRisePlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class CraftingManager {
    private final PowerRisePlugin plugin;
    public static final String REBIRTH_STONE_NAME = ChatColor.LIGHT_PURPLE + "Piedra del Renacer";
    
    public CraftingManager(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    public void registerCustomRecipes() {
        registerRebirthStoneRecipe();
    }
    
    private void registerRebirthStoneRecipe() {
        ItemStack rebirthStone = createRebirthStone();
        NamespacedKey key = new NamespacedKey(plugin, "rebirth_stone");
        
        ShapedRecipe recipe = new ShapedRecipe(key, rebirthStone);
        recipe.shape("DED", "ENE", "DED");
        recipe.setIngredient('D', Material.DIAMOND);
        recipe.setIngredient('E', Material.ENDER_PEARL);
        recipe.setIngredient('N', Material.NETHER_STAR);
        
        plugin.getServer().addRecipe(recipe);
    }
    
    public static ItemStack createRebirthStone() {
        ItemStack stone = new ItemStack(Material.END_CRYSTAL);
        ItemMeta meta = stone.getItemMeta();
        
        meta.setDisplayName(REBIRTH_STONE_NAME);
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Una piedra mística que permite",
            ChatColor.GRAY + "cambiar tu poder actual por uno nuevo.",
            "",
            ChatColor.YELLOW + "Clic derecho para usar",
            ChatColor.RED + "⚠ Perderás tu poder actual"
        ));
        
        stone.setItemMeta(meta);
        return stone;
    }
    
    public static boolean isRebirthStone(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        return meta.hasDisplayName() && meta.getDisplayName().equals(REBIRTH_STONE_NAME);
    }
}
