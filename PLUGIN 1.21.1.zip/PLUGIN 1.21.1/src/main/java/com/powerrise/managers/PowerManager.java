package com.powerrise.managers;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.powers.PowerType;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;


import java.util.*;

public class PowerManager {
    private final PowerRisePlugin plugin;
    private final Map<Player, Integer> skyLightningCounter = new HashMap<>();
    private final Map<Player, Location> shadowDomainCenters = new HashMap<>();
    private final Map<Player, Set<Block>> shadowDomainBlocks = new HashMap<>();
    private final Map<Player, Location> skyRingCenters = new HashMap<>();
    private final Map<Player, BukkitTask> activeEffectTasks = new HashMap<>();
private final Set<UUID> skyLightningCooldown = new HashSet<>();

    public PowerManager(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    // ===== FUEGO =====
    
    public void activateFireAbility1(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_1")) {
            player.sendMessage(ChatColor.RED + "🔒 ¡Necesitas 1 kill para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_1")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_1") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        // Lanzar bola de fuego que NO daña al usuario
        Fireball fireball = player.launchProjectile(Fireball.class);
        fireball.setShooter(player); // ✅ Required for self-damage cancel
        fireball.setYield(3.0f); // Explosion size
        fireball.setIsIncendiary(true); // Sets fire (can leave it if desired)

        
        // Efectos visuales y sonoros
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.FLAME, loc, 30, 0.5, 0.5, 0.5, 0.1);
        loc.getWorld().spawnParticle(Particle.LAVA, loc, 10, 0.3, 0.3, 0.3, 0);
        loc.getWorld().playSound(loc, Sound.ENTITY_GHAST_SHOOT, 1.0f, 1.2f);
        loc.getWorld().playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 0.8f, 0.9f);
        
        // Establecer cooldown
        data.setCooldown(powerName + "_ability_1", 8000); // 8 segundos
        
        // Mensaje de éxito
        player.sendMessage(ChatColor.RED + "🔥 ¡BOLA DE FUEGO LANZADA!");
        player.sendTitle(ChatColor.RED + "🔥", ChatColor.YELLOW + "Bola de Fuego", 5, 15, 5);
    }
    
    public void activateFireAbility2(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_2")) {
            player.sendMessage(ChatColor.RED + "🔒 ¡Necesitas 3 kills para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_2")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_2") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }

        player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 500, 0)); // Fuerza I por 25s

        
        // Activar aura de fuego por 25 segundos
        data.setCooldown("fire_aura_active", 25000);
        data.setCooldown(powerName + "_ability_2", 45000);
        
        // Efectos visuales épicos
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.FLAME, loc, 100, 2, 2, 2, 0.2);
        loc.getWorld().spawnParticle(Particle.LAVA, loc, 20, 1, 1, 1, 0);
        loc.getWorld().spawnParticle(Particle.SMOKE_LARGE, loc, 30, 1.5, 1.5, 1.5, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_BLAZE_AMBIENT, 1.0f, 0.8f);
        loc.getWorld().playSound(loc, Sound.BLOCK_FIRE_EXTINGUISH, 1.0f, 0.5f);
        
        player.sendMessage(ChatColor.RED + "🔥 ¡AURA DE FUEGO ACTIVADA!");
        player.sendTitle(ChatColor.RED + "🔥", ChatColor.YELLOW + "Aura Ardiente - 25s", 5, 20, 5);
        
        // Efecto visual continuo
        startFireAuraEffect(player);
    }
    
    public void activateFireAbility3(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_3")) {
            player.sendMessage(ChatColor.RED + "🔒 ¡Necesitas 5 kills para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_3")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_3") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        Location loc = player.getLocation();
        
        // Gran explosión que NO daña al usuario
        loc.getWorld().createExplosion(loc, 6.0f, true, true, player);
        
        // Daño a enemigos cercanos (EXCLUYENDO al usuario)
        Collection<Entity> nearby = loc.getWorld().getNearbyEntities(loc, 8, 8, 8);
        for (Entity entity : nearby) {
            if (entity instanceof Player && !entity.equals(player)) {
                Player target = (Player) entity;
                target.damage(14.0, player);
                target.setFireTicks(200); // 10 segundos de fuego
            }
        }
        
        // Efectos épicos mejorados
        loc.getWorld().spawnParticle(Particle.EXPLOSION_HUGE, loc, 8, 2, 2, 2, 0);
        loc.getWorld().spawnParticle(Particle.FLAME, loc, 200, 6, 6, 6, 0.3);
        loc.getWorld().spawnParticle(Particle.LAVA, loc, 50, 4, 4, 4, 0);
        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.5f);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 0.8f);
        
        data.setCooldown(powerName + "_ability_3", 60000);
        
        player.sendMessage(ChatColor.RED + "🔥 ¡EXPLOSIÓN DEVASTADORA!");
        player.sendTitle(ChatColor.RED + "💥", ChatColor.YELLOW + "Devastación Total", 5, 30, 5);
    }
    
    // ===== CIELO =====
    
    public void activateSkyAbility1(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_1")) {
            player.sendMessage(ChatColor.AQUA + "🔒 ¡Necesitas 1 kill para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_1")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_1") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        // Dash hacia CUALQUIER DIRECCIÓN (hacia donde mira el jugador)
        Vector direction = player.getEyeLocation().getDirection();
        direction.normalize();
        direction.multiply(4.0); // Velocidad del dash
        
        // Si mira hacia abajo, dash hacia abajo; si hacia arriba, hacia arriba
        player.setVelocity(direction);
        
        // Efectos visuales épicos en la dirección del dash
        Location loc = player.getLocation();
        Location targetLoc = loc.clone().add(direction.clone().multiply(2));
        
        // Partículas en línea del dash
        for (int i = 0; i < 20; i++) {
            Location particleLoc = loc.clone().add(direction.clone().multiply(i * 0.5));
            particleLoc.getWorld().spawnParticle(Particle.CLOUD, particleLoc, 3, 0.2, 0.2, 0.2, 0);
            particleLoc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, particleLoc, 2, 0.1, 0.1, 0.1, 0.1);
        }
        
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_FLAP, 1.0f, 1.5f);
        loc.getWorld().playSound(loc, Sound.ENTITY_PHANTOM_SWOOP, 1.0f, 1.2f);
        
        data.setCooldown(powerName + "_ability_1", 12000);
        
        player.sendMessage(ChatColor.AQUA + "☁️ ¡DASH CELESTIAL!");
        player.sendTitle(ChatColor.AQUA + "☁️", ChatColor.YELLOW + "Dash Celestial", 5, 15, 5);
    }

public void handleSkyLightningAttack(Player player, Player target) {
    PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);

    // ✅ Solo cuando el poder SKY está activo
    if (!hasSkyLightning(data)) return;

    // ✅ Prevenir rayos repetidos al mismo objetivo en corto tiempo
    if (skyLightningCooldown.contains(target.getUniqueId())) return;

    // ✅ Contador por jugador
    int count = skyLightningCounter.getOrDefault(player, 0) + 1;
    skyLightningCounter.put(player, count);

    if (count >= 3) {
        // ⚡ Efecto visual del rayo
        target.getWorld().strikeLightningEffect(target.getLocation());

        // ✅ Daño con scheduler para evitar conflictos de hilos
        Bukkit.getScheduler().runTask(plugin, () -> {
                applyTrueDamage(target, 3.0, player);
        });

        // ✅ Resetear contador
        skyLightningCounter.put(player, 0);

        // ✅ Mensaje para el jugador que lanzó la habilidad
        player.sendMessage(ChatColor.AQUA + "⚡ ¡RAYO CELESTIAL!");

        // ✅ Cooldown de 1 segundos por objetivo
        UUID targetId = target.getUniqueId();
        skyLightningCooldown.add(targetId);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            skyLightningCooldown.remove(targetId);
        }, 20L); // 20 ticks = 1 segundos
    }
}


    
    public void activateSkyAbility2(Player player) {
    PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
    String powerName = data.getCurrentPower().name().toLowerCase();

    if (!data.hasAbilityUnlocked(powerName + "_ability_2")) {
        player.sendMessage(ChatColor.AQUA + "🔒 ¡Necesitas 3 kills para desbloquear esta habilidad!");
        player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
        return;
    }

    if (data.isOnCooldown(powerName + "_ability_2")) {
        long remaining = data.getRemainingCooldown(powerName + "_ability_2") / 1000;
        player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
        return;
    }

    // Activate lightning tracking and set cooldowns
    data.setCooldown("sky_lightning_active", 30000); // 30s lightning ability
    data.setCooldown(powerName + "_ability_2", 45000); // 45s cooldown before reuse
    skyLightningCounter.put(player, 0); // Reset lightning counter

    // Visual and audio feedback
    Location loc = player.getLocation();
    loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 100, 2, 3, 2, 0.2);
    loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 50, 1, 2, 1, 0.1);
    loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.2f);
    loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.8f, 1.5f);

    player.sendMessage(ChatColor.AQUA + "⚡ ¡PODER DEL RAYO ACTIVADO!");
    player.sendTitle(ChatColor.AQUA + "⚡", ChatColor.YELLOW + "Poder del Rayo - 30s", 5, 20, 5);
}

    
    public void activateSkyAbility3(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_3")) {
            player.sendMessage(ChatColor.AQUA + "🔒 ¡Necesitas 5 kills para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_3")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_3") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        // Crear anillo ESTÁTICO que dura exactamente 12 segundos
        Location ringCenter = player.getLocation().clone(); // Clonar para que sea estático
        skyRingCenters.put(player, ringCenter);
        
        data.setCooldown("sky_ring_active", 12000); // 12 segundos exactos
        data.setCooldown(powerName + "_ability_3", 50000);
        
        // Efectos visuales iniciales épicos
        ringCenter.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, ringCenter, 200, 6, 2, 6, 0.3);
        ringCenter.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, ringCenter, 100, 4, 1, 4, 0.2);
        ringCenter.getWorld().spawnParticle(Particle.END_ROD, ringCenter, 50, 5, 1, 5, 0.1);
        ringCenter.getWorld().playSound(ringCenter, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 2.0f, 1.0f);
        ringCenter.getWorld().playSound(ringCenter, Sound.ENTITY_WITHER_SPAWN, 1.0f, 1.5f);
        
        player.sendMessage(ChatColor.AQUA + "🌪️ ¡ANILLO CELESTIAL ESTÁTICO!");
        player.sendTitle(ChatColor.AQUA + "🌪️", ChatColor.YELLOW + "Anillo Celestial - 12s", 5, 30, 5);
        
        // Efecto continuo del anillo ESTÁTICO
        startSkyRingEffect(player, ringCenter);
    }
    
    // ===== SOMBRAS =====
    
    public void activateShadowAbility1(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_1")) {
            player.sendMessage(ChatColor.DARK_PURPLE + "🔒 ¡Necesitas 1 kill para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_1")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_1") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        // Invisibilidad por 15 segundos
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 300, 0));
        
        // Efectos visuales mejorados
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.SMOKE_LARGE, loc, 50, 2, 2, 2, 0.2);
        loc.getWorld().spawnParticle(Particle.PORTAL, loc, 30, 1, 1, 1, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.5f);
        loc.getWorld().playSound(loc, Sound.ENTITY_PHANTOM_AMBIENT, 0.8f, 0.8f);
        
        data.setCooldown(powerName + "_ability_1", 25000);
        
        player.sendMessage(ChatColor.DARK_PURPLE + "👻 ¡INVISIBILIDAD ACTIVADA!");
        player.sendTitle(ChatColor.DARK_PURPLE + "👻", ChatColor.YELLOW + "Invisibilidad - 15s", 5, 20, 5);
    }
    
    public void activateShadowAbility2(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_2")) {
            player.sendMessage(ChatColor.DARK_PURPLE + "🔒 ¡Necesitas 3 kills para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_2")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_2") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        // Crear anillo de ceguera mejorado por 15 segundos
        data.setCooldown("shadow_ring_active", 15000);
        data.setCooldown(powerName + "_ability_2", 30000);
        
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.SMOKE_LARGE, loc, 150, 6, 1, 6, 0.2);
        loc.getWorld().spawnParticle(Particle.PORTAL, loc, 100, 4, 0.5, 4, 0.1);
        loc.getWorld().spawnParticle(Particle.SQUID_INK, loc, 50, 3, 0.5, 3, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_WITHER_AMBIENT, 1.0f, 1.5f);
        loc.getWorld().playSound(loc, Sound.ENTITY_PHANTOM_HURT, 1.0f, 0.8f);
        
        player.sendMessage(ChatColor.DARK_PURPLE + "🌑 ¡ANILLO DE CEGUERA MEJORADO!");
        player.sendTitle(ChatColor.DARK_PURPLE + "🌑", ChatColor.YELLOW + "Anillo de Ceguera - 15s", 5, 20, 5);
        
        // Efecto continuo del anillo mejorado
        startShadowRingEffect(player);
    }
    
    public void activateShadowAbility3(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_3")) {
            player.sendMessage(ChatColor.DARK_PURPLE + "🔒 ¡Necesitas 5 kills para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_3")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_3") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        // Dominio de sombras que se EXPANDE con bloques físicos por 20 segundos
        data.setCooldown("shadow_domain_active", 20000);
        data.setCooldown(powerName + "_ability_3", 60000);
        
        Location center = player.getLocation();
        shadowDomainCenters.put(player, center);
        
        // Crear bloques de obsidiana temporales alrededor
        Set<Block> domainBlocks = new HashSet<>();
        for (int x = -6; x <= 6; x++) {
            for (int z = -6; z <= 6; z++) {
                for (int y = -1; y <= 3; y++) {
                    Location blockLoc = center.clone().add(x, y, z);
                    double distance = center.distance(blockLoc);
                    
                    // Crear paredes del dominio
                    if (distance >= 5.5 && distance <= 6.5) {
                        Block block = blockLoc.getBlock();
                        
                         if (!block.getType().isSolid() ||
                            block.getType() == Material.GRASS_BLOCK ||
                            block.getType() == Material.TALL_GRASS) {

                            domainBlocks.add(block);
                            block.setType(Material.OBSIDIAN);
                        }
                        
                    }
                }
            }
        }
        
        shadowDomainBlocks.put(player, domainBlocks);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
        for (Block block : shadowDomainBlocks.getOrDefault(player, Collections.emptySet())) {
            if (block.getType() == Material.OBSIDIAN) {
                block.setType(Material.AIR);
            }
        }
        shadowDomainBlocks.remove(player);
        }, 15 * 20L);

        // Efectos al usuario
        player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 400, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 400, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 400, 0)); // Speed I
        
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.PORTAL, loc, 300, 10, 10, 10, 1.0);
        loc.getWorld().spawnParticle(Particle.SMOKE_LARGE, loc, 200, 8, 8, 8, 0.5);
        loc.getWorld().playSound(loc, Sound.ENTITY_WITHER_SPAWN, 2.0f, 0.8f);
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 0.5f);
        
        player.sendMessage(ChatColor.DARK_PURPLE + "🌀 ¡DOMINIO DE SOMBRAS EXPANDIDO!");
        player.sendTitle(ChatColor.DARK_PURPLE + "🌀", ChatColor.YELLOW + "Dominio Absoluto - 20s", 5, 30, 5);
        
        // Efecto continuo del dominio
        startShadowDomainEffect(player);
    }
    
    // ===== TIERRA =====
    
    public void activateEarthAbility1(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_1")) {
            player.sendMessage(ChatColor.GREEN + "🔒 ¡Necesitas 1 kill para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_1")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_1") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        Location loc = player.getLocation();
        
        // Lanzar enemigos por los aires
        Collection<Entity> nearby = loc.getWorld().getNearbyEntities(loc, 5, 5, 5);
        for (Entity entity : nearby) {
            if (entity instanceof Player && !entity.equals(player)) {
                Player target = (Player) entity;
                Vector launch = new Vector(0, 4, 0);
                target.setVelocity(launch);
                applyTrueDamage(target, 2.5, player);


                
        Location under = target.getLocation().clone().subtract(0, 1, 0);
under.getWorld().spawnParticle(Particle.BLOCK_CRACK, under, 20, 0.5, 0.5, 0.5, 0.2, Material.STONE.createBlockData());
under.getWorld().playSound(under, Sound.BLOCK_STONE_BREAK, 1.2f, 0.8f);
            }
        }


        
        // Efectos visuales mejorados
        loc.getWorld().spawnParticle(Particle.EXPLOSION_NORMAL, loc, 10, 1, 1, 1, 0.1);
        loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 100, 2, 1, 2, 0.2, Material.GRAVEL.createBlockData());
        loc.getWorld().playSound(loc, Sound.BLOCK_STONE_BREAK, 1.5f, 0.5f);
        loc.getWorld().playSound(loc, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0f, 0.6f);
        loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 200, 4, 0.2, 4, 0.2, 
                                   Material.DIRT.createBlockData());
        loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 100, 3, 0.1, 3, 0.1,
                                   Material.STONE.createBlockData());
        loc.getWorld().playSound(loc, Sound.ENTITY_RAVAGER_ROAR, 1.0f, 0.8f);
        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 0.5f);
        
        data.setCooldown(powerName + "_ability_1", 10000);
        
        player.sendMessage(ChatColor.GREEN + "🌍 ¡TERREMOTO!");
        player.sendTitle(ChatColor.GREEN + "🌍", ChatColor.YELLOW + "Terremoto", 5, 20, 5);
    }
    
    public void activateEarthAbility2(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_2")) {
            player.sendMessage(ChatColor.GREEN + "🔒 ¡Necesitas 3 kills para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_2")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_2") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        // Reducir 70% del daño por 10 segundos
        data.setCooldown("earth_shield_active", 10000);
        data.setCooldown(powerName + "_ability_2", 30000);
        
        // Efectos visuales mejorados
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 100, 2, 2, 2, 0.2,
                                   Material.STONE.createBlockData());
        loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 50, 1, 1, 1, 0.1,
                                   Material.IRON_BLOCK.createBlockData());
        loc.getWorld().playSound(loc, Sound.BLOCK_ANVIL_PLACE, 1.0f, 0.5f);
        loc.getWorld().playSound(loc, Sound.BLOCK_STONE_PLACE, 1.0f, 0.3f);
        
        player.sendMessage(ChatColor.GREEN + "🛡️ ¡ESCUDO DE TIERRA ACTIVADO!");
        player.sendTitle(ChatColor.GREEN + "🛡️", ChatColor.YELLOW + "Escudo Protector - 10s", 5, 20, 5);
        
        // Efecto visual continuo
        startEarthShieldEffect(player);
    }
    
    public void activateEarthAbility3(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        String powerName = data.getCurrentPower().name().toLowerCase();
        
        if (!data.hasAbilityUnlocked(powerName + "_ability_3")) {
            player.sendMessage(ChatColor.GREEN + "🔒 ¡Necesitas 5 kills para desbloquear esta habilidad!");
            player.sendMessage(ChatColor.GRAY + "Kills actuales: " + data.getTotalKills());
            return;
        }
        
        if (data.isOnCooldown(powerName + "_ability_3")) {
            long remaining = data.getRemainingCooldown(powerName + "_ability_3") / 1000;
            player.sendMessage(ChatColor.RED + "⏰ Habilidad en cooldown: " + remaining + "s restantes");
            return;
        }
        
        Location center = player.getLocation();
        
        // Levantar bloques y luego aplastarlos
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            // Fase 1: Levantar bloques
            for (int x = -5; x <= 5; x++) {
                for (int z = -5; z <= 5; z++) {
                    Location blockLoc = center.clone().add(x, 0, z);
                    blockLoc.getWorld().spawnParticle(Particle.BLOCK_CRACK, blockLoc.add(0, 3, 0), 
                                                    30, 0.8, 0.8, 0.8, 0.2, Material.STONE.createBlockData());
                    blockLoc.getWorld().spawnParticle(Particle.BLOCK_CRACK, blockLoc, 
                                                    20, 0.5, 0.5, 0.5, 0.1, Material.DIRT.createBlockData());
                }
            }
            
            center.getWorld().playSound(center, Sound.ENTITY_RAVAGER_STUNNED, 2.0f, 0.5f);
            center.getWorld().playSound(center, Sound.ENTITY_WITHER_HURT, 1.0f, 0.3f);
            
            // Fase 2: Aplastar después de .5 segundos
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                Collection<Entity> nearby = center.getWorld().getNearbyEntities(center, 7, 7, 7);
                for (Entity entity : nearby) {
                    if (entity instanceof Player && !entity.equals(player)) {
                        Player target = (Player) entity;
                        applyTrueDamage(target, 6.0, player);

                    }
                }

                Location loc = center.clone().subtract(0, 1, 0);
                center.getWorld().createExplosion(loc, 15.0f, false, true, player);
                
                // Efectos de aplastamiento épicos
                center.getWorld().spawnParticle(Particle.EXPLOSION_NORMAL, center, 10, 1, 1, 1, 0.1);
                center.getWorld().spawnParticle(Particle.BLOCK_CRACK, center, 100, 2, 1, 2, 0.2, Material.GRAVEL.createBlockData());
                center.getWorld().playSound(center, Sound.BLOCK_STONE_BREAK, 1.5f, 0.5f);
                center.getWorld().playSound(center, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0f, 0.6f);
                center.getWorld().spawnParticle(Particle.BLOCK_CRACK, center, 400, 6, 2, 6, 0.3, Material.COBBLESTONE.createBlockData());
                center.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, center, 10, 3, 1, 3, 0);
                center.getWorld().playSound(center, Sound.ENTITY_RAVAGER_ATTACK, 2.0f, 0.3f);
                center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 1f);
                
            }, 10L); // 0.5 segundos
            
        }, 5L);
        
        data.setCooldown(powerName + "_ability_3", 45000);
        
        player.sendMessage(ChatColor.GREEN + "🌍 ¡APLASTAMIENTO SÍSMICO MEJORADO!");
        player.sendTitle(ChatColor.GREEN + "⛰️", ChatColor.YELLOW + "Aplastamiento Sísmico", 5, 30, 5);
    }
    
    // ===== MÉTODOS DE EFECTOS CONTINUOS =====
    
    private void startFireAuraEffect(Player player) {
        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            
            @Override
            public void run() {
                PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
                if (!data.isOnCooldown("fire_aura_active") || !player.isOnline()) {
                    cancel();
                    activeEffectTasks.remove(player);
                    return;
                }
                
                // Efectos visuales del aura mejorados
                Location loc = player.getLocation();
                loc.getWorld().spawnParticle(Particle.FLAME, loc, 15, 1.5, 1.5, 1.5, 0.1);
                loc.getWorld().spawnParticle(Particle.LAVA, loc, 3, 0.8, 0.8, 0.8, 0);
                
                if (ticks % 40 == 0) { // Cada 2 segundos
                    loc.getWorld().playSound(loc, Sound.BLOCK_FIRE_AMBIENT, 0.4f, 1.2f);
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 2L);
        
        activeEffectTasks.put(player, task);
    }
    
    private void startEarthShieldEffect(Player player) {
        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
                if (!data.isOnCooldown("earth_shield_active") || !player.isOnline()) {
                    cancel();
                    activeEffectTasks.remove(player);
                    return;
                }
                
                Location loc = player.getLocation();
                loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 8, 0.8, 1.5, 0.8, 0.1,
                                           Material.STONE.createBlockData());
                loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 3, 0.5, 1, 0.5, 0.1,
                                           Material.IRON_BLOCK.createBlockData());
            }
        }.runTaskTimer(plugin, 0L, 10L);
        
        activeEffectTasks.put(player, task);
    }
    
    private void startShadowRingEffect(Player player) {
        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            
            @Override
            public void run() {
                PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
                if (!data.isOnCooldown("shadow_ring_active") || !player.isOnline()) {
                    cancel();
                    activeEffectTasks.remove(player);
                    return;
                }
                
                Location center = player.getLocation();
                
                // Crear anillo de partículas MEJORADO
                for (int i = 0; i < 360; i += 8) {
                    double radians = Math.toRadians(i);
                    double x = center.getX() + 5 * Math.cos(radians);
                    double z = center.getZ() + 5 * Math.sin(radians);
                    Location particleLoc = new Location(center.getWorld(), x, center.getY() + 0.5, z);
                    
                    center.getWorld().spawnParticle(Particle.SMOKE_LARGE, particleLoc, 2, 0.1, 0.1, 0.1, 0);
                    center.getWorld().spawnParticle(Particle.PORTAL, particleLoc, 1, 0, 0, 0, 0);
                    
                    if (ticks % 20 == 0) { // Efectos adicionales cada segundo
                        center.getWorld().spawnParticle(Particle.SQUID_INK, particleLoc, 1, 0, 0, 0, 0);
                    }
                }
                
                // Aplicar ceguera y lentitud a enemigos dentro del anillo
                Collection<Entity> nearby = center.getWorld().getNearbyEntities(center, 5, 5, 5);
                for (Entity entity : nearby) {
                    if (entity instanceof Player && !entity.equals(player)) {
                        Player target = (Player) entity;
                        target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0));
                        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 60, 0));
                    }
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 10L);
        
        activeEffectTasks.put(player, task);
    }
    
    private void startShadowDomainEffect(Player player) {
        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            
            @Override
            public void run() {
                PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
                if (!data.isOnCooldown("shadow_domain_active") || !player.isOnline()) {
                    // Limpiar bloques del dominio
                    Set<Block> blocks = shadowDomainBlocks.remove(player);
                    if (blocks != null) {
                        for (Block block : blocks) {
                            if (block.getType() == Material.OBSIDIAN) {
                                block.setType(Material.AIR);
                            }
                        }
                    }
                    shadowDomainCenters.remove(player);
                    cancel();
                    activeEffectTasks.remove(player);
                    return;
                }
                
                Location center = shadowDomainCenters.get(player);
                if (center != null) {
                    // Efectos visuales del dominio mejorados
                    center.getWorld().spawnParticle(Particle.PORTAL, center, 30, 8, 8, 8, 0.2);
                    center.getWorld().spawnParticle(Particle.SMOKE_LARGE, center, 20, 6, 6, 6, 0.1);
                    
                    if (ticks % 40 == 0) { // Cada 2 segundos
                        center.getWorld().playSound(center, Sound.ENTITY_WITHER_AMBIENT, 0.5f, 0.8f);
                    }
                    
                    // Aplicar efectos a enemigos
                    Collection<Entity> nearby = center.getWorld().getNearbyEntities(center, 8, 8, 8);
                    for (Entity entity : nearby) {
                        if (entity instanceof Player && !entity.equals(player)) {
                            Player target = (Player) entity;
                            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 60, 1));
                            target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0));
                        }
                    }
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 20L);
        
        activeEffectTasks.put(player, task);
    }

    
    
    private void startSkyRingEffect(Player player, Location staticCenter) {
        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            
            @Override
            public void run() {
                PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
                if (!data.isOnCooldown("sky_ring_active") || !player.isOnline()) {
                    skyRingCenters.remove(player);
                    cancel();
                    activeEffectTasks.remove(player);
                    return;
                }
                
                // Crear anillo de partículas ÉPICO y ESTÁTICO
                for (int i = 0; i < 360; i += 3) {
                    double radians = Math.toRadians(i);
                    double x = staticCenter.getX() + 6 * Math.cos(radians);
                    double z = staticCenter.getZ() + 6 * Math.sin(radians);
                    Location particleLoc = new Location(staticCenter.getWorld(), x, staticCenter.getY() + 1, z);
                    
                    staticCenter.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, particleLoc, 2, 0.1, 0.1, 0.1, 0.1);
                    staticCenter.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, particleLoc, 1, 0, 0, 0, 0);
                    
                    if (ticks % 10 == 0) { // Efectos adicionales
                        staticCenter.getWorld().spawnParticle(Particle.END_ROD, particleLoc, 1, 0, 0, 0, 0);
                    }
                }
                
                // Daño continuo a enemigos dentro del anillo ESTÁTICO
                Collection<Entity> nearby = staticCenter.getWorld().getNearbyEntities(staticCenter, 6, 6, 6);
                for (Entity entity : nearby) {
                    if (entity instanceof Player && !entity.equals(player)) {
                        Player target = (Player) entity;
                        applyTrueDamage(target, 0.5, player);
                        
                        // Efecto visual en el objetivo
                        target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, target.getLocation(), 5, 0.3, 0.3, 0.3, 0.1);
                    }
                }
                
                if (ticks % 10 == 0) { // Sonido cada medio segundo
                    staticCenter.getWorld().playSound(staticCenter, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.3f, 1.5f);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 10L); // Cada medio segundo
        
        activeEffectTasks.put(player, task);
    }
    
    // ===== MÉTODOS DE VERIFICACIÓN =====
    
    public boolean hasFireAura(PlayerData data) {
        return data.isOnCooldown("fire_aura_active");
    }
    
    public boolean hasEarthShield(PlayerData data) {
        return data.isOnCooldown("earth_shield_active");
    }
    
    public boolean hasSkyLightning(PlayerData data) {
        return data.isOnCooldown("sky_lightning_active");
    }
    
    // Limpiar efectos cuando el jugador se desconecta
    public void cleanupPlayer(Player player) {
        BukkitTask task = activeEffectTasks.remove(player);
        if (task != null) {
            task.cancel();
        }
        
        // Limpiar bloques del dominio si existen
        Set<Block> blocks = shadowDomainBlocks.remove(player);
        if (blocks != null) {
            for (Block block : blocks) {
                if (block.getType() == Material.OBSIDIAN) {
                    block.setType(Material.AIR);
                }
            }
        }
        
        skyLightningCounter.remove(player);
        shadowDomainCenters.remove(player);
        skyRingCenters.remove(player);
    }

public void applyTrueDamage(Player target, double amount, Player damager) {
    // Mostrar animación, sonido y evento
    target.damage(0.1, damager);

    // Knockback manual (hacia afuera desde el atacante)
    Vector direction = target.getLocation().toVector().subtract(damager.getLocation().toVector()).normalize();
    target.setVelocity(direction.multiply(0.20).setY(0.166)); // Ajusta fuerza según necesites

    // Aplicar daño real ignorando todo
    Bukkit.getScheduler().runTaskLater(PowerRisePlugin.getInstance(), () -> {
        if (target.isDead()) return;

        double finalHealth = target.getHealth() - (amount * 2);
        if (finalHealth <= 0) {
            target.setHealth(0);
            target.setLastDamageCause(new EntityDamageByEntityEvent(damager, target, EntityDamageEvent.DamageCause.CUSTOM, amount));
        } else {
            target.setHealth(finalHealth);
        }
    }, 1L);
}
}
