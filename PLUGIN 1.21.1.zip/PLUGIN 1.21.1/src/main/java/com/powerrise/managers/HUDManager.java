package com.powerrise.managers;

import com.powerrise.PowerRisePlugin;
import com.powerrise.data.PlayerData;
import com.powerrise.powers.PowerType;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class HUDManager {
    private final PowerRisePlugin plugin;
    
    public HUDManager(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    public void startHUD(Player player) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                
                updateHUD(player);
            }
        }.runTaskTimer(plugin, 0L, 20L); // Actualizar cada segundo
    }
    
    private void updateHUD(Player player) {
        try {
            PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
            PowerType power = data.getCurrentPower();
            
            if (power == null) return;
            
            StringBuilder actionBar = new StringBuilder();
            String powerName = power.name().toLowerCase();
            
            // Título del poder con emoji
            actionBar.append(power.getFormattedName()).append(" ");
            actionBar.append(ChatColor.GRAY).append("| ");
            actionBar.append(ChatColor.GREEN).append("Kills: ").append(data.getTotalKills()).append(" ");
            
            // Separador
            actionBar.append(ChatColor.GRAY).append("|| ");
            
            // Habilidades con cooldowns correctos
            // Habilidad 1 (X)
            actionBar.append(getAbilityDisplay(data, powerName + "_ability_1", "X", 1));
            actionBar.append(" ");
            
            // Habilidad 2 (C)
            actionBar.append(getAbilityDisplay(data, powerName + "_ability_2", "C", 3));
            actionBar.append(" ");
            
            // Habilidad 3 (V)
            actionBar.append(getAbilityDisplay(data, powerName + "_ability_3", "V", 5));
            
            // Enviar como action bar
            player.sendActionBar(actionBar.toString());
            
        } catch (Exception e) {
            plugin.getLogger().warning("Error actualizando HUD para " + player.getName() + ": " + e.getMessage());
        }
    }
    
    private String getAbilityDisplay(PlayerData data, String abilityKey, String keyName, int requiredKills) {
        // Verificar si está desbloqueada
        if (!data.hasAbilityUnlocked(abilityKey)) {
            return ChatColor.DARK_GRAY + "[" + keyName + ": " + requiredKills + " kills]";
        }
        
        // Verificar cooldown
        if (data.isOnCooldown(abilityKey)) {
            long remaining = data.getRemainingCooldown(abilityKey) / 1000;
            return ChatColor.RED + "[" + keyName + ": " + remaining + "s]";
        }
        
        // Disponible
        return ChatColor.GREEN + "[" + keyName + ": ✓]";
    }
}
