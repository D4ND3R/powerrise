package com.powerrise.managers;

import com.powerrise.PowerRisePlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class KeyItemManager {
    private final PowerRisePlugin plugin;
    
    // Nombres únicos para identificar los items
    public static final String X_KEY_NAME = ChatColor.GREEN + "🔥 Habilidad X";
    public static final String C_KEY_NAME = ChatColor.YELLOW + "⚡ Habilidad C";
    public static final String V_KEY_NAME = ChatColor.RED + "💀 Habilidad V";
    
    public KeyItemManager(PowerRisePlugin plugin) {
        this.plugin = plugin;
    }
    
    public void giveKeyItems(Player player) {
        // Limpiar items anteriores
        removeKeyItems(player);
        
        // Dar los 3 items de habilidades
        player.getInventory().setItem(6, createXKeyItem()); // Slot 7
        player.getInventory().setItem(7, createCKeyItem()); // Slot 8  
        player.getInventory().setItem(8, createVKeyItem()); // Slot 9
        
        // Mensaje explicativo
        player.sendMessage("");
        player.sendMessage(ChatColor.GOLD + "🎮 ¡Items de habilidades agregados!");
        player.sendMessage(ChatColor.GRAY + "Usa clic derecho con cada item para activar habilidades");
        player.sendMessage("");
    }
    
    private ItemStack createXKeyItem() {
        ItemStack item = new ItemStack(Material.BLAZE_POWDER);
        ItemMeta meta = item.getItemMeta();
        
        meta.setDisplayName(X_KEY_NAME);
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Clic derecho para usar",
            ChatColor.GREEN + "Primera habilidad (1 kill)",
            "",
            ChatColor.DARK_GRAY + "Simula la tecla X"
        ));
        
        // Hacer que brille
        meta.addEnchant(Enchantment.DURABILITY, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        
        item.setItemMeta(meta);
        return item;
    }
    
    private ItemStack createCKeyItem() {
        ItemStack item = new ItemStack(Material.GLOWSTONE_DUST);
        ItemMeta meta = item.getItemMeta();
        
        meta.setDisplayName(C_KEY_NAME);
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Clic derecho para usar",
            ChatColor.YELLOW + "Segunda habilidad (3 kills)",
            "",
            ChatColor.DARK_GRAY + "Simula la tecla C"
        ));
        
        // Hacer que brille
        meta.addEnchant(Enchantment.DURABILITY, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        
        item.setItemMeta(meta);
        return item;
    }
    
    private ItemStack createVKeyItem() {
        ItemStack item = new ItemStack(Material.REDSTONE);
        ItemMeta meta = item.getItemMeta();
        
        meta.setDisplayName(V_KEY_NAME);
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Clic derecho para usar",
            ChatColor.RED + "Tercera habilidad (5 kills)",
            "",
            ChatColor.DARK_GRAY + "Simula la tecla V"
        ));
        
        // Hacer que brille
        meta.addEnchant(Enchantment.DURABILITY, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        
        item.setItemMeta(meta);
        return item;
    }
    
    public void removeKeyItems(Player player) {
        for (int i = 0; i < player.getInventory().getSize(); i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (isKeyItem(item)) {
                player.getInventory().setItem(i, null);
            }
        }
    }
    
    public static boolean isKeyItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) return false;
        
        String name = meta.getDisplayName();
        return name.equals(X_KEY_NAME) || name.equals(C_KEY_NAME) || name.equals(V_KEY_NAME);
    }
    
    public static boolean isXKeyItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getDisplayName().equals(X_KEY_NAME);
    }
    
    public static boolean isCKeyItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getDisplayName().equals(C_KEY_NAME);
    }
    
    public static boolean isVKeyItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getDisplayName().equals(V_KEY_NAME);
    }
}
